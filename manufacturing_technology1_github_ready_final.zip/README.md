# Manufacturing Technology-I Online Assessment

A browser-based assessment for diploma-level Manufacturing Technology-I covering non-traditional machining processes.

## Features
- MCQ and fill-in-the-blank questions
- Automatic scoring for objective questions and keyword-assisted scoring for written responses
- Question-by-question assessment flow
- Basic browser activity/visibility warnings
- Downloadable result report
- Email submission through a Google Apps Script web app endpoint

## Files
- `index.html` — assessment page
- `Code.gs` — Google Apps Script email endpoint
- `LICENSE` — MIT license

## Deploy to GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html`, `Code.gs`, `README.md`, and `LICENSE` to the repository root.
3. In GitHub, open **Settings → Pages**.
4. Under build/deployment, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site. The URL will appear in the Pages settings.

## Configure instructor email delivery
1. Open `Code.gs` in [Google Apps Script](https://script.google.com/).
2. Set `RECIPIENT_EMAIL` to the intended instructor email address(es).
3. Deploy as a **Web app**:
   - Execute as: **Me**
   - Who has access: **Anyone** (or the narrowest access setting compatible with your use)
4. Authorize the script and copy the deployed web-app URL ending in `/exec`.
5. In `index.html`, find `APPS_SCRIPT_ENDPOINT` and replace its value with your deployed URL.
6. Commit the updated `index.html` to GitHub and redeploy if needed.
7. Submit a test attempt and verify that the email arrives. Browser-side `no-cors` requests cannot confirm delivery to the page, so check the inbox and Apps Script execution log.

## Important limitations
- Browser-based anti-cheating checks are deterrents, not secure proctoring. A student can bypass client-side checks or modify local HTML.
- Written answers may receive provisional keyword-based scores and should be reviewed by the instructor.
- Do not publish private student data, credentials, or access codes in a public repository. Consider using a private repository or changing the access code before publishing.
