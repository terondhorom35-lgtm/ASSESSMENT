/**
 * Google Apps Script email endpoint for the Manufacturing Technology-I assessment.
 * Deploy this script as a Web app (Execute as: Me).
 */
const RECIPIENT_EMAIL = "jontorapadang35@gmail.com";

function doPost(e) {
  try {
    const raw = e && e.postData && e.postData.contents ? e.postData.contents : "{}";
    const data = JSON.parse(raw);
    const reportText = String(data.reportText || "No report text was included.");
    const studentName = String(data.studentName || "Student");
    const subject = "Manufacturing Technology-I Assessment Submission — " + studentName;

    MailApp.sendEmail({
      to: RECIPIENT_EMAIL,
      subject: subject,
      body: reportText
    });

    return ContentService
      .createTextOutput(JSON.stringify({ ok: true, message: "Email sent" }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ ok: false, error: String(err) }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet() {
  return ContentService
    .createTextOutput("Manufacturing Technology-I assessment email endpoint is running.")
    .setMimeType(ContentService.MimeType.TEXT);
}
